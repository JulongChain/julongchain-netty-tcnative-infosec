/* serv.cpp  -  Minimal ssleay server for Unix
   30.9.1996, Sampo Kellomaki <sampo@iki.fi> */


/* mangled to work with SSLeay-0.9.0b and OpenSSL 0.9.2b
   Simplified to be even more minimal
   12/98 - 4/99 Wade Scholine <wades@mail.cybg.com> */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <memory.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#include <openssl/rsa.h>       /* SSLeay stuff */
#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>


/* define HOME to be dir for key and cert files... */
#define HOME "../../../certs/rsa/server/"
/* Make these what you want for cert & key files */
#define CAF    HOME "ca.crt"
#define CERTF  HOME "server.crt"
#define KEYF   HOME "server.key"
#define PASSWORD "111111"


#define CHK_NULL(x) if ((x)==NULL) exit (1)
#define CHK_ERR(err,s) if ((err)<0) { perror(s); exit(1); }
#define CHK_SSL(err) if ((err<=0)) { ERR_print_errors_fp(stderr); exit(2); }

int main ()
{
	int err = 1;
	int listen_sd;
	int sd;
	struct sockaddr_in sa_serv;
	struct sockaddr_in sa_cli;
	size_t client_len;
	SSL_CTX* ctx;
	SSL*     ssl;
	X509*    client_cert;
	char*    str;
	char     buf [4096];
	SSL_METHOD *meth;

	int      nid;
	EC_KEY  *ecdh;
	/* SSL preliminaries. We keep the certificate and key with the context. */

	SSL_load_error_strings();
	SSLeay_add_ssl_algorithms();

#if 0
	meth = (SSL_METHOD*)TLSv1_1_server_method();
#else
	meth = (SSL_METHOD*)SSLv23_server_method();
#endif
	ctx = SSL_CTX_new (meth);
	if (!ctx) {
		ERR_print_errors_fp(stderr);
		exit(2);
	}

	SSL_CTX_set_options(ctx, SSL_OP_CIPHER_SERVER_PREFERENCE);
	nid = OBJ_sn2nid((const char *)"prime256v1");
	if (nid == 0) {
		return -1;
	}

	ecdh = EC_KEY_new_by_curve_name(nid);
	if (ecdh == NULL) {
		return -1;
	}

	SSL_CTX_set_options(ctx, SSL_OP_SINGLE_ECDH_USE);    //ljk

	SSL_CTX_set_tmp_ecdh(ctx, ecdh);

	EC_KEY_free(ecdh);

	SSL_CTX_set_cipher_list(ctx, "AES128-SHA:AES256-SHA:ECDHE-RSA-AES128-SHA:ECDHE-RSA-AES256-SHA");

	if (SSL_CTX_use_certificate_file(ctx, CERTF, SSL_FILETYPE_PEM) <= 0) {
		ERR_print_errors_fp(stderr);
		exit(3);
	}

	SSL_CTX_set_default_passwd_cb_userdata(ctx, (void*)PASSWORD);
	if (SSL_CTX_use_PrivateKey_file(ctx, KEYF, SSL_FILETYPE_PEM) <= 0) {
		ERR_print_errors_fp(stderr);
		exit(4);
	}

	if (!SSL_CTX_check_private_key(ctx)) {
		fprintf(stderr,"Private key does not match the certificate public key\n");
		exit(5);
	}

	SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER|SSL_VERIFY_FAIL_IF_NO_PEER_CERT, NULL);
	/* Load certificates of trusted CAs based on file provided*/
	if (SSL_CTX_load_verify_locations(ctx, CAF, NULL)<1) {
		fprintf(stderr,"Error setting the verify locations.\n");
		exit(6);
	}
	SSL_CTX_set_client_CA_list(ctx, SSL_load_client_CA_file(CAF));

	/* ----------------------------------------------- */
	/* Prepare TCP socket for receiving connections */

	listen_sd = socket (AF_INET, SOCK_STREAM, 0);   CHK_ERR(listen_sd, "socket");

	memset (&sa_serv, '\0', sizeof(sa_serv));
	sa_serv.sin_family      = AF_INET;
	sa_serv.sin_addr.s_addr = INADDR_ANY;
	sa_serv.sin_port        = htons (443);          /* Server Port number */

	int flag = 1;
	setsockopt(listen_sd, SOL_SOCKET, SO_REUSEADDR, &flag, sizeof(int));
	err = bind(listen_sd, (struct sockaddr*) &sa_serv,
			sizeof (sa_serv));                   CHK_ERR(err, "bind");

	/* Receive a TCP connection. */

	err = listen (listen_sd, 5);                    CHK_ERR(err, "listen");

	client_len = sizeof(sa_cli);
	sd = accept (listen_sd, (struct sockaddr*) &sa_cli, (socklen_t*)&client_len);
	CHK_ERR(sd, "accept");
	close (listen_sd);

	printf ("Connection from %s, port %hu\n",
			inet_ntoa(sa_cli.sin_addr), ntohs(sa_cli.sin_port));

	/* ----------------------------------------------- */
	/* TCP connection is ready. Do server side SSL. */

	ssl = SSL_new (ctx);                           CHK_NULL(ssl);
	SSL_set_fd (ssl, sd);

	/* Is the SSL_connection established? */
	if(SSL_is_init_finished(ssl) == false)
	{
#if 1
		err = SSL_accept(ssl);    CHK_SSL(err);
#else
		SSL_set_accept_state(ssl);
		err = SSL_do_handshake(ssl);                        CHK_SSL(err);
#endif
	}

	if(err <= 0)
		printf("SSL handshake error: %d\n", SSL_get_error(ssl, err));

	if((err = SSL_get_verify_result(ssl)) != X509_V_OK)
		printf("SSL verify peer certificate error: %d: %s\n", err, X509_verify_cert_error_string(err));

	/* Get the cipher - opt */

	printf ("SSL connection using %s\n", SSL_get_cipher (ssl));

	/* Get client's certificate (note: beware of dynamic allocation) - opt */
	if(SSL_get_verify_mode(ssl) & (SSL_VERIFY_PEER|SSL_VERIFY_FAIL_IF_NO_PEER_CERT))
	{
		client_cert = SSL_get_peer_certificate (ssl);
		if (client_cert != NULL) {
			printf ("Client certificate:\n");

			str = X509_NAME_oneline (X509_get_subject_name (client_cert), 0, 0);
			CHK_NULL(str);
			printf ("\t subject: %s\n", str);
			OPENSSL_free (str);

			str = X509_NAME_oneline (X509_get_issuer_name  (client_cert), 0, 0);
			CHK_NULL(str);
			printf ("\t issuer: %s\n", str);
			OPENSSL_free (str);

			/* We could do all sorts of certificate verification stuff here before
			   deallocating the certificate. */

			X509_free (client_cert);
		}
		else
			printf ("Client does not have certificate.\n");
	}

	/* DATA EXCHANGE - Receive message and send reply. */
Again:
	err = SSL_read (ssl, buf, sizeof(buf) - 1);                   CHK_SSL(err);
	if(SSL_pending(ssl))
		goto Again;
	buf[err] = '\0';
	printf ("Got %d chars:'%s'\n", err, buf);

	err = SSL_write (ssl, "I hear you.", strlen("I hear you."));  CHK_SSL(err);

	/* Clean up. */

	close (sd);
	SSL_free (ssl);
	SSL_CTX_free (ctx);

	return 0;
}
/* EOF - serv.cpp */
