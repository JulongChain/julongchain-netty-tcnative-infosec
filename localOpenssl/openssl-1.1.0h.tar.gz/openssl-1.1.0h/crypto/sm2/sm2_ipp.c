#ifdef OPENSSL_WITH_INTEL
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>              // for O_RDONLY
#include <unistd.h>
#include <time.h>
#include "sm2_ipp.h"

static const uint8_t sm2abgxgy[] = {
    0xFF, 0xFF, 0xFF, 0xFE, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00,
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFC, 0x28, 0xE9, 0xFA, 0x9E,
    0x9D, 0x9F, 0x5E, 0x34, 0x4D, 0x5A, 0x9E, 0x4B, 0xCF, 0x65, 0x09, 0xA7,
    0xF3, 0x97, 0x89, 0xF5, 0x15, 0xAB, 0x8F, 0x92, 0xDD, 0xBC, 0xBD, 0x41,
    0x4D, 0x94, 0x0E, 0x93, 0x32, 0xC4, 0xAE, 0x2C, 0x1F, 0x19, 0x81, 0x19,
    0x5F, 0x99, 0x04, 0x46, 0x6A, 0x39, 0xC9, 0x94, 0x8F, 0xE3, 0x0B, 0xBF,
    0xF2, 0x66, 0x0B, 0xE1, 0x71, 0x5A, 0x45, 0x89, 0x33, 0x4C, 0x74, 0xC7,
    0xBC, 0x37, 0x36, 0xA2, 0xF4, 0xF6, 0x77, 0x9C, 0x59, 0xBD, 0xCE, 0xE3,
    0x6B, 0x69, 0x21, 0x53, 0xD0, 0xA9, 0x87, 0x7C, 0xC6, 0x2A, 0x47, 0x40,
    0x02, 0xDF, 0x32, 0xE5, 0x21, 0x39, 0xF0, 0xA0
};

static const uint8_t sm2id[] =
    { 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x31, 0x32, 0x33, 0x34,
    0x35, 0x36, 0x37, 0x38
};

static Ipp32u sm2n[] =
    { 0x39D54123, 0x53BBF409, 0x21C6052B, 0x7203DF6B, 0xFFFFFFFF, 0xFFFFFFFF,
    0xFFFFFFFF, 0xFFFFFFFE
};

// new BN
static IppsBigNumState *nBN (int dS, const Ipp32u * A)
// new (positive) BigNum
{                               // dS - data Size in Ipp32u words,
    int ctxSize;                // A - data Array, ctxSize - BigNum contex Size
    ippsBigNumGetSize (dS, &ctxSize);   // get the BigNum context Size
    IppsBigNumState *BN =
        (IppsBigNumState *) ippMalloc (sizeof (Ipp8u) * ctxSize);
    ippsBigNumInit (dS, BN);    // BigNum context initialization
    if (A)
        ippsSet_BN (IppsBigNumPOS, dS, A, BN);  // set the sign
    return BN;                  // and the value
}

static IppsBigNumState *nBNSM2 ()
{
    int ctxSize;                //  ctxSize - BigNum contex Size
    ippsBigNumGetSize (SM2_INTS, &ctxSize);     // get the BigNum context Size
    IppsBigNumState *bn =
        (IppsBigNumState *) ippMalloc (sizeof (Ipp8u) * ctxSize);
    ippsBigNumInit (SM2_INTS, bn);      // BigNum context initialization
    return bn;
}

// new ECCP
static IppsECCPState *nECCP (int bitS)
{
    int size;
    ippsECCPGetSize (bitS, &size);
    IppsECCPState *ECCP = (IppsECCPState *) ippMalloc (sizeof (Ipp8u) * size);
    ippsECCPInit (bitS, ECCP);
    return ECCP;
}

// new ECCP point
static IppsECCPPointState *nECCPPoint (int bitS, int pSize)
{
    IppsECCPPointState *point =
        (IppsECCPPointState *) ippMalloc (sizeof (Ipp8u) * pSize);
    ippsECCPPointInit (bitS, point);
    return point;
}

#ifndef USING_PRNG
static void randIpp8u (Ipp8u * ru, int size)
{
    int randomData = open ("/dev/urandom", O_RDONLY);
    size_t randomDataLen = 0;
    while (randomDataLen < size)
    {
        ssize_t result =
            read (randomData, ru + randomDataLen, size - randomDataLen);
        randomDataLen += result;
    }
    close (randomData);
}
#endif

static Ipp32u *randIpp32u (Ipp32u * ra, int size)
{
    int n;
#ifdef USING_PRNG
    for (n = 0; n < size; n++)
    {
        ra[n] = (random () << 16) + random ();
    }
#else
    Ipp8u *r8u = (Ipp8u *) malloc (sizeof (Ipp8u) * size * 4);
    int m;
    randIpp8u (r8u, size * 4);
    for (n = 0; n < size; n++)
    {
        for (m = 0; m < 4; m++)
        {
            ra[n] <<= 8;
            ra[n] += r8u[n * 4 + m];
        }
    }
    if (r8u)
        free (r8u);
#endif
    return ra;
}

static IppsPRNGState *nPRNG (int sBits)
{
    int sSize = (sBits + 31) >> 5;
    Ipp32u *seed = (Ipp32u *) ippMalloc (sizeof (Ipp32u) * sSize);
    int bnSize = 256;
    IppsBigNumState *Tmp;
    //ippsPRNGGetSize (&bnSize);
    IppsPRNGState *Ctx = (IppsPRNGState *) ippMalloc (sizeof (Ipp8u) * bnSize);
    ippsPRNGInit (sBits, Ctx);
    ippsPRNGSetSeed (Tmp = nBN (sSize, randIpp32u (seed, sSize)), Ctx);
    if (Tmp)
        ippFree (Tmp);
    if (seed)
        ippFree (seed);
    return Ctx;
}

static IppsPRNGState *newPRNG (void)
{
    int ctxSize;
    ippsPRNGGetSize (&ctxSize);
    IppsPRNGState *pCtx =
        (IppsPRNGState *) ippMalloc (sizeof (Ipp8u) * ctxSize);
    ippsPRNGInit (256, pCtx);
    return pCtx;
}

IppStatus randFunc (Ipp32u * pRandBNU, int nbits, void *pCtx)
{
    randIpp32u (pRandBNU, SM2_INTS);
    return ippStsNoErr;
}

int
sm2_sign_hash (const uint8_t * msg_hash, const uint32_t msg_hash_len,
               const uint8_t * priv_key, const uint32_t priv_output_length,
               unsigned char *signature, uint32_t * const siglen)
{
    int idx, size, pointSize;
    IppStatus w;
    IppsBigNumState *digest, *priv, *signx, *signy;
    ippInit ();
    //Standard SM2 setting
    ippsECCPGetSize (SM2_BITS, &size);
    IppsECCPState *eccp = nECCP (SM2_BITS);
    //Selected SM2 Curve
    w = ippsECCPSetStd (ippEC_TPM_SM2_P256, eccp);
    //Generating ephemeral keypair
    IppsBigNumState *ephPriv = nBNSM2 ();       //nBN (SM2_BITS/ 32);
    ippsECCPPointGetSize (SM2_BITS, &pointSize);
    IppsECCPPointState *ephPub = nECCPPoint (SM2_BITS, pointSize);
    IppsPRNGState *Rand = newPRNG ();   //nPRNG (SM2_BITS); //'external' PRNG
    /* ippsPRNGen only for testing, you' cant't get different random at runtime. */
    //ippsECCPGenKeyPair (ephPriv, ephPub, eccp, ippsPRNGen, Rand);
    /* override ippsPRNGen for productivity , you'll get different ephemeral private key at runtime.  
     * And then , we can get different signature result at runtime.*/
    /* It's important for signature security of SM2 using different ephemeral private key */
    ippsECCPGenKeyPair (ephPriv, ephPub, eccp, randFunc, Rand);
    ippsECCPSetKeyPair (ephPriv, ephPub, ippFalse, eccp);
    ippsECCPPublicKey (ephPriv, ephPub, eccp);

    //Init digest
    digest = nBNSM2 ();
    w = ippsSetOctString_BN (msg_hash, msg_hash_len, digest);

    //Initialize private key
    priv = nBNSM2 ();
    w = ippsSetOctString_BN (priv_key, priv_output_length, priv);

    //Initialize signature.x
    signx = nBNSM2 ();
    //Initialize signature.y
    signy = nBNSM2 ();

    do
    {
        w = ippsECCPSignSM2 (digest, priv, ephPriv, signx, signy, eccp);
        if (w != ippStsNoErr)
            printf ("SM2 Sign Error for %s\n", ippGetStatusString (w));
    }
    while (w == ippStsRangeErr || w == ippStsEphemeralKeyErr);

    if (w == ippStsNoErr)
    {
        Ipp8u x[32] = { 0 }
        , y[32] =
        {
        0};
        ippsGetOctString_BN (x, 32, signx);
        ippsGetOctString_BN (y, 32, signy);
        int length_x = 32, length_y = 32;
        //construct signature 
        // SIGNATURE :==SEQUENCE{
        //    R INTEGER,
        //    S INTEGER
        //    }
        if ((x[0] & 0xFF) > 0x7f)
            length_x = 0x21;
        if ((y[0] & 0xFF) > 0x7f)
            length_y = 0x21;
        *siglen = length_x + length_y + 6;
        memset (signature, 0, *siglen);

        signature[0] = 0x30;
        signature[1] = length_x + length_y + 4;
        signature[2] = 0x02;
        signature[3] = length_x;
        memcpy (signature + (length_x - 28), x, 32);
        signature[4 + length_x] = 0x02;
        signature[5 + length_x] = length_y;
        memcpy (signature + (6 + length_x + length_y - 32), y, 32);
        //*siglen = length_x + length_y + 6;
    }
    else
    {
        printf ("SM2 Sign Error for %s\n", ippGetStatusString (w));
    }

    if (eccp)
        ippFree (eccp);
    if (digest)
        ippFree (digest);
    if (priv)
        ippFree (priv);
    if (ephPriv)
        ippFree (ephPriv);
    if (ephPub)
        ippFree (ephPub);
    if (signx)
        ippFree (signx);
    if (signy)
        ippFree (signy);
    if (Rand)
        ippFree (Rand);
    return w != ippStsNoErr ? 0 : 1;
}

int
sm2_verify_hash (const uint8_t * signature, const uint32_t sign_length,
                 const uint8_t * msg_hash,
                 const uint32_t msg_hash_length,
                 const uint8_t * pub_key, const uint32_t pub_output_length)
{
    int size, pointSize;
    IppStatus w;
    IppsBigNumState *digest, *pubx, *puby, *signx, *signy;
    IppECResult Result;

    ippInit ();
    //Standard SM2 setting
    ippsECCPGetSize (SM2_BITS, &size);
    IppsECCPState *eccp = nECCP (SM2_BITS);
    ippsECCPSetStd (ippEC_TPM_SM2_P256, eccp);
    //Init digest
    digest = nBNSM2 ();
    ippsSetOctString_BN (msg_hash, msg_hash_length, digest);

    int length_x, length_y;
    length_x = signature[3];
    length_y = signature[5 + length_x];
    //Initialize signature.x
    signx = nBNSM2 ();
    ippsSetOctString_BN (signature + 4, length_x, signx);
    //Initialize signature.y
    signy = nBNSM2 ();
    ippsSetOctString_BN (signature + 6 + length_x, length_y, signy);

    // construct public key
    ippsECCPPointGetSize (SM2_BITS, &pointSize);
    IppsECCPPointState *pub = nECCPPoint (SM2_BITS, pointSize);
    pubx = nBNSM2 ();
    // convert Octet String to public key x
    ippsSetOctString_BN (pub_key + 1, 32, pubx);
    puby = nBNSM2 ();
    // convert Octet String to public key y
    ippsSetOctString_BN (pub_key + 33, 32, puby);
    w = ippsECCPSetPoint (pubx, puby, pub, eccp);

    w = ippsECCPVerifySM2 (digest, pub, signx, signy, &Result, eccp);
	if (w != ippStsNoErr || Result != ippECValid)
		printf ("SM2 Verify Error for %s\n", ippGetStatusString (w));

    if (digest)
        ippFree (digest);
    if (pubx)
        ippFree (pubx);
    if (puby)
        ippFree (puby);
    if (signx)
        ippFree (signx);
    if (signy)
        ippFree (signy);
    if (pub)
        ippFree (pub);
    if (eccp)
        ippFree (eccp);
    return w != ippStsNoErr ? 0 : 1;
}

static int
generate_za (const uint8_t * id, const uint32_t id_len_bytes,
             const uint8_t * public_key, const uint32_t public_key_len_bytes,
             uint8_t * const z_output)
{

    /*
     *            ZA= H256(ENTLA||IDA||a||b||xG||yG||xA||yA) 
     *                     */
    int entla = id_len_bytes * 8;
    uint8_t length[2];

    if (id == NULL || public_key == NULL || public_key_len_bytes < 64)
        return 0;

    length[1] = entla & 0xFF;
    length[0] = (entla >> 8) & 0xFF;
    int ctxSize;
    ippsSM3GetSize (&ctxSize);
    //context for the first half of the message
    IppsSM3State *ctxsm3 =
        (IppsSM3State *) ippMalloc (sizeof (Ipp8u) * ctxSize);
    ippsSM3Init (ctxsm3);
    ippsSM3Update (length, 2, ctxsm3);
    ippsSM3Update (id, id_len_bytes, ctxsm3);
    ippsSM3Update (sm2abgxgy, 128, ctxsm3);
    ippsSM3Update (public_key + 1, 64, ctxsm3);
    ippsSM3Final (z_output, ctxsm3);
    if (ctxsm3)
        ippFree (ctxsm3);

    return 1;
}

static int
kdf_sm3 (const uint8_t * z_input, const int z_len,
         const int klen, uint8_t const *outkey)
{
#define SM3_DIGEST_SIZE 32
    int i, ctxSize;
    uint8_t zz[4] = { 0 };
    uint8_t digest[SM3_DIGEST_SIZE];
    IppsSM3State *ctx;
    int rlen = klen;

    uint8_t *pp = (uint8_t *) outkey;
    /* couter start from 1, every step increase 1, stop it until we get the key  
     */
    ippsSM3GetSize (&ctxSize);
    ctx = (IppsSM3State *) ippMalloc (sizeof (Ipp8u) * ctxSize);
    i = 1;
    while (rlen > 0)
    {
        zz[0] = (i >> 24) & 0xff;
        zz[1] = (i >> 16) & 0xFF;
        zz[2] = (i >> 8) & 0xFF;
        zz[3] = i & 0xff;

        ippsSM3Init (ctx);
        ippsSM3Update (z_input, z_len, ctx);
        ippsSM3Update (zz, 4, ctx);
        ippsSM3Final (digest, ctx);
        memcpy (pp, digest, (rlen >= SM3_DIGEST_SIZE) ? SM3_DIGEST_SIZE : rlen);
        rlen -= SM3_DIGEST_SIZE;
        pp += SM3_DIGEST_SIZE;
        i++;
    }
    if (ctx)
        ippFree (ctx);
    return ((klen + SM3_DIGEST_SIZE - 1) / SM3_DIGEST_SIZE) * SM3_DIGEST_SIZE;
}


/*
 * A1:generating a random k, k between 1 and n-1 ;
 * A2:compute point C1=[k]G=(x1,y1), convert C1 to octet string;
 * A3:compute point S=[k]PB=(x2,y2), if S is infinite Point, return;
 * A4:convert point S to octet string;
 * A5:key derive t=KDF(x2 || y2, klen), if t are all zero , return A1;
 * A6:generate ciphertext C2 = M xor t
 * A7:gengerate digest C3 = Hash(x2 || M || y2)
 * A8:output ciphertext C = C1 || C3 || C2
 */
#define SM2_PUBLIC_KEY_SIZE 65
#define SM2_SIZE 32

int
sm2_encrypt (uint8_t * const ciphertext,
             uint32_t * const ciphertext_len_bytes,
             const uint8_t * plaintext,
             const uint32_t plaintext_len_bytes,
             const uint8_t * public_key, const uint32_t public_key_len_bytes)
{

    IppsBigNumState *k, *x1, *y1, *pGx, *pGy;
    IppsPRNGState *pPrngState;
    IppStatus w;
    IppsECCPState *eccp;
    IppsECCPPointState *pG, *pkg;
    int i, pSize, pointSize;
    ippInit ();
    k = nBNSM2 ();
    w = ippsECCPGetSizeStdSM2 (&pSize);
    pPrngState = nPRNG (SM2_INTS);
    // A1: generate random k
    w = ippsPRNGen_BN (k, SM2_BITS, pPrngState);
    //contruct base point
    pGx = nBNSM2 ();
    pGy = nBNSM2 ();
    eccp = nECCP (pSize);
    //Select SM2 curve
    w = ippsECCPSetStd (ippEC_TPM_SM2_P256, eccp);
    w = ippsECCPPointGetSize (pSize, &pointSize);
    pG = nECCPPoint (pSize, pointSize);
    //get the base point from SM2 curve parameter
    //w = ippsECCPGetPoint (pGx, pGy, pG, eccp);//get base point from curve, but it doesn't work always
    w = ippsSetOctString_BN (sm2abgxgy + 64, SM2_SIZE, pGx);    //copy gx to BigNum
    w = ippsSetOctString_BN (sm2abgxgy + 96, SM2_SIZE, pGy);    //copy gy to BigNum

    w = ippsECCPSetPoint (pGx, pGy, pG, eccp);

    pkg = nECCPPoint (pSize, pointSize);

    //compute C1(x1,y1) = [k]G 
    w = ippsECCPMulPointScalar (pG, k, pkg, eccp);
    x1 = nBNSM2 ();
    y1 = nBNSM2 ();
    w = ippsECCPGetPoint (x1, y1, pkg, eccp);

    /* ciphertext structure:
     *  sequence {
     *  x integer
     *  y integer
     *  c3 octect_string
     *  c2 octet_string
     *  }
     *  */
    int seq_len, x_len, y_len, c3_len, c2_len;
    // copy x1 & y1 to xyh 
    Ipp8u xyh[96];              //store x y and digest
    Ipp8u xy[SM2_SIZE + SM2_SIZE];
    memset (xyh, 0, 96);

    w = ippsGetOctString_BN (xyh, SM2_SIZE, x1);        //save x1 to xyh
    w = ippsGetOctString_BN (xyh + SM2_SIZE, SM2_SIZE, y1);     // save y1 to xyh
    //compute S(x2,y2) = [k] PB
    w = ippsSetOctString_BN (public_key + 1, SM2_SIZE, x1);
    w = ippsSetOctString_BN (public_key + 1 + SM2_SIZE, SM2_SIZE, y1);
    // convert PB to point
    w = ippsECCPSetPoint (x1, y1, pG, eccp);    //create point
    w = ippsECCPMulPointScalar (pG, k, pkg, eccp);      //compute [k]PB
    w = ippsECCPGetPoint (x1, y1, pkg, eccp);   // convert point to coordiante

    ippsGetOctString_BN (xy, SM2_SIZE, x1);
    ippsGetOctString_BN (xy + SM2_SIZE, SM2_SIZE, y1);

	//for(i=0;i<64;i++) printf("%02x ",xy[i]); 
	
    //generate C3 = SM3(x2 || plaintext || y2)
    int sm3CtxSize;
    ippsSM3GetSize (&sm3CtxSize);
    IppsSM3State *sm3Ctx =
        (IppsSM3State *) ippMalloc (sizeof (Ipp8u) * sm3CtxSize);

    ippsSM3Init (sm3Ctx);
    ippsSM3Update (xy, SM2_SIZE, sm3Ctx);
    ippsSM3Update (plaintext, plaintext_len_bytes, sm3Ctx);
    ippsSM3Update (xy + SM2_SIZE, SM2_SIZE, sm3Ctx);
    ippsSM3Final (xyh + SM2_SIZE + SM2_SIZE, sm3Ctx);   //store digest to xyh

    if (sm3Ctx)
        ippFree (sm3Ctx);

    //key derive t=KDF(x2||y2, klen)
    Ipp8u *key = (Ipp8u *) ippMalloc (plaintext_len_bytes);
    kdf_sm3 (xy, SM2_SIZE + SM2_SIZE, plaintext_len_bytes, key);
/*
    //generate ciphertext C2 = plaintext XOR t
    // compute length of C2
    int c2_len_len = asn1_len_length (plaintext_len_bytes);
    int c2_delta = 0, c3_delta = 0, x_delta = 0, y_delta = 0, pos;
    if (plaintext[0] ^ key[0] > 0x7F)
        c2_delta = 1;           // check c2[0]
    if (xyh[0] > 0x7F)
        x_delta = 1;            // check x[0]
    if (xyh[32] > 0x7F)
        y_delta = 1;            // check y[0]
    if (xyh[64] > 0x7F)
        c3_delta = 1;           //check c3[0]
    seq_len =
        104 + x_delta + y_delta + c3_delta + c2_len_len + plaintext_len_bytes;
    int seq_len_len = asn1_len_length (seq_len);
    *ciphertext_len_bytes = 2 + seq_len + seq_len_len;  //length of ciphertext

    // clean ciphertext and prepare to copy cipher text
    memset (ciphertext, 0, *ciphertext_len_bytes);
    pos = 0;
    //sequence
    ciphertext[pos] = 0x30;
    length_to_asn1 (ciphertext + 1, seq_len);
    pos += 2 + seq_len_len;
    //integer(x)
    ciphertext[pos] = 0x02;
    pos += 1;
    ciphertext[pos] = 0x20 + x_delta;
    pos += 1 + x_delta;
    memcpy (ciphertext + pos, xyh, 32); // copy x
    pos += 32;
    //integer(y)
    ciphertext[pos] = 0x02;
    pos += 1;
    ciphertext[pos] = 0x20 + y_delta;
    pos += 1 + y_delta;
    memcpy (ciphertext + pos, xyh + 32, 32);    //copy y
    pos += 32;
    // C3 -- OCTET STRING
    ciphertext[pos] = 0x04;
    pos += 1;
    ciphertext[pos] = 0x20 + c3_delta;
    pos += 1 + c3_delta;
    memcpy (ciphertext + pos, xyh + 64, 32);    // copy c3
    pos += 32;
    // C2 -- OCTET STRING
    ciphertext[pos] = 0x04;
    pos += 1;
    length_to_asn1 (ciphertext + pos, plaintext_len_bytes);
    pos += 1 + c2_len_len;

    for (i = 0; i < plaintext_len_bytes; i++)
        ciphertext[pos + i] = plaintext[i] ^ key[i];    // encrypting plaintext
*/		
	
	//开始加上0x04
	ciphertext[0] = 0x04;
	memcpy(ciphertext + 1, xyh, sizeof(xyh));
	
    for (i = 0; i < plaintext_len_bytes; i++)
	{
        ciphertext[96 + 1 + i] = plaintext[i] ^ key[i];    // encrypting plaintext
	}
	*ciphertext_len_bytes = 96 + 1 + i;
    
	if (k)
        ippFree (k);
    if (x1)
        ippFree (x1);
    if (y1)
        ippFree (y1);
    if (pGx)
        ippFree (pGx);
    if (pGy)
        ippFree (pGy);
    if (pPrngState)
        ippFree (pPrngState);
    if (key)
        ippFree (key);
    if (eccp)
        ippFree (eccp);
    if (pG)
        ippFree (pG);
    if (pkg)
        ippFree (pkg);

	return w != ippStsNoErr ? 0 : 1;
}

int
sm2_decrypt (uint8_t * const outputtext,
             uint32_t * const outputtext_len_bytes,
             const uint8_t * ciphertext,
             const uint32_t ciphertext_len_bytes,
             const uint8_t * private_key, const uint32_t private_key_len_bytes)
{

    IppsBigNumState *da, *x1, *y1;
    IppStatus w;
    IppsECCPState *eccp;
    IppsECCPPointState *pPB, *pkg;
    int i, size, pointSize, pSize;
    Ipp8u xy[64];
    Ipp8u digest[32];

    ippInit ();
    da = nBNSM2 ();
    ippsECCPGetSizeStdSM2 (&pSize);
    eccp = nECCP (pSize);
    //Select SM2 curve
    w = ippsECCPSetStd (ippEC_TPM_SM2_P256, eccp);
    ippsECCPPointGetSize (pSize, &pointSize);
    pPB = nECCPPoint (pSize, pointSize);
    pkg = nECCPPoint (pSize, pointSize);

    //compute C1(x1,y1) = [da]PB 
    ippsSetOctString_BN (private_key, private_key_len_bytes, da);
    x1 = nBNSM2 ();
    y1 = nBNSM2 ();
	
	
    /* parsing encrypted message *
     * sequence {
     * x integer,
     * y integer,
     * c3 octet_string,
     * c2 octet_string
     * }
     */
	 
    int seq_len, seq_len_len, c3_len, c2_len, c2_len_len, c3_pos, pos, x_len,
        y_len;
/*		
#ifndef _OLD_FORMAT
    //get length of sequence
    pos = 1;                    //skip sequence tag
    seq_len = parse_asn1_length (ciphertext + pos, &seq_len_len);
    pos += 2 + seq_len_len;     //seek length and integer(x) tag
    x_len = ciphertext[pos];
    if (x_len > 0x20)
    {
        pos += 1;
        x_len -= 1;
    }
    ippsSetOctString_BN (ciphertext + pos + 1, x_len, x1);
    pos += 2 + x_len;           // seek length and integer(y) tag

    y_len = ciphertext[pos];
    if (y_len > 0x20)
    {
        pos += 1;
        y_len -= 1;
    }
    ippsSetOctString_BN (ciphertext + pos + 1, y_len, y1);
    pos += 2 + y_len;
    c3_len = ciphertext[pos];
    c3_pos = pos + 1;
    if (c3_len > 0x20)
    {
        c3_pos += 1;
        c3_len -= 1;
    }
    pos += 1 + ciphertext[pos];
    c2_len = parse_asn1_length (ciphertext + pos + 1, &c2_len_len);
    pos += 2;
    if (ciphertext[pos + c2_len_len] == 0
        && ciphertext[1 + pos + c2_len_len] > 127)
    {
        c2_len -= 1;
        pos += 1;
    }
#else
    ippsSetOctString_BN (ciphertext + 1, 32, x1);
    ippsSetOctString_BN (ciphertext + 33, 32, y1);
#endif
*/	
	//----------------------------------------
    ippsSetOctString_BN (ciphertext + 1, 32, x1);
    ippsSetOctString_BN (ciphertext + 32 + 1, 32, y1);
	//----------------------------------------
	
    w = ippsECCPSetPoint (x1, y1, pPB, eccp);
    w = ippsECCPMulPointScalar (pPB, da, pkg, eccp);
    w = ippsECCPGetPoint (x1, y1, pkg, eccp);
	
	
	
    ippsGetOctString_BN (xy, 32, x1);
    ippsGetOctString_BN (xy + 32, 32, y1);
	
	//for(i=0;i<64;i++) printf("%02x ",xy[i]); 
	
	//------------------------------------------
	//cipher len
	c2_len = ciphertext_len_bytes - 1 - 96;

	//------------------------------------------
	
	
	
    //key derive t=KDF(x2||y2, klen)
    //int c2_len= ciphertext_len_bytes - 97;
    Ipp8u *key = (Ipp8u *) ippMalloc (c2_len);
    kdf_sm3 (xy, 64, c2_len, key);
    //printf("xy:");for(i=0;i<64;i++) printf("%02x ",xy[i]); printf("\n");
    //printf("decrypt key:");for(i=0;i<c2_len;i++) printf("%02x ",key[i]);
    //generate ciphertext C2 = plaintext XOR t
    *outputtext_len_bytes = c2_len;
	/*
    for (i = 0; i < c2_len; i++)
    {
        outputtext[i] = ciphertext[pos + c2_len_len + i] ^ key[i];
    }*/
	//------------------------------------------
    for (i = 0; i < c2_len; i++)
    {
        outputtext[i] = ciphertext[96 + 1 + i] ^ key[i];
    }	
	//------------------------------------------

    //generate C3 = SM3(x2 || plaintext || y2)
    int sm3CtxSize;
    ippsSM3GetSize (&sm3CtxSize);
    IppsSM3State *sm3Ctx =
        (IppsSM3State *) ippMalloc (sizeof (Ipp8u) * sm3CtxSize);
    ippsSM3Init (sm3Ctx);
    ippsSM3Update (xy, 32, sm3Ctx);
    ippsSM3Update (outputtext, c2_len, sm3Ctx);
    ippsSM3Update (xy + 32, 32, sm3Ctx);
    ippsSM3Final (digest, sm3Ctx);
    if (sm3Ctx)
        ippFree (sm3Ctx);

    if (key)
        ippFree (key);

    if (da)
        ippFree (da);
    if (x1)
        ippFree (x1);
    if (y1)
        ippFree (y1);
    if (eccp)
        ippFree (eccp);
    if (pPB)
        ippFree (pPB);
    if (pkg)
        ippFree (pkg);
/*
    for (i = 0; i < 32; i++)
        if (digest[i] != ciphertext[c3_pos + i])
        {
            //        printf ("Failed!\n");
            return 0;
        }
*/

	for (i = 0; i < 32; i++)
	if (digest[i] != ciphertext[64 + 1+ i])
	{
		return 0;
	}

	return w != ippStsNoErr ? 0 : 1;
}

/*
 * compute 2^128+(x2&(2^128-1))
 */
static IppsBigNumState *w2h (IppsBigNumState * x2)
{
    Ipp32u w2[4], x2u[8];
    int i, ctxSize, half;
    half = 4;
    ippsBigNumGetSize (half, &ctxSize);
    IppsBigNumState *pw2 =
        (IppsBigNumState *) ippMalloc (sizeof (Ipp8u) * ctxSize);
    ippsBigNumInit (half, pw2);
    ippsExtGet_BN (0, 0, x2u, x2);      // convert IppsBigNumState to Ipp32u
    for (i = 0; i < half; i++)
        w2[i] = x2u[i];

    w2[half - 1] = 0x80000000 | (w2[half - 1] & 0x7FFFFFFF);

    ippsSet_BN (IppsBigNumPOS, half, w2, pw2);
    return pw2;
}

static IppStatus sm2_MontMul_BN (IppsBigNumState * a, IppsBigNumState * b,
                          Ipp32u * pnData, IppsBigNumState ** r)
{
    int size;
    IppStatus w;

    //define and initialize Montgomery Engine over Modulus N
    ippsMontGetSize (IppsBinaryMethod, SM2_INTS, &size);
    IppsMontState *pMont = (IppsMontState *) ippMalloc (sizeof (Ipp8u) * size);
    ippsMontInit (IppsBinaryMethod, SM2_INTS, pMont);
    ippsMontSet (pnData, SM2_INTS, pMont);

    //initialize Big Number multiplicant A
    IppsBigNumState *ar = nBNSM2 ();
    ippsMontForm (a, pMont, ar);

    // compute R=A*B mod N
    w = ippsMontMul (ar, b, pMont, *r);

    if (pMont)
        ippFree (pMont);
    if (ar)
        ippFree (ar);

    return w;
}

static IppsBigNumState *nBNOctString (const uint8_t * oct)
{
    IppsBigNumState *bn = nBNSM2 ();
    ippsSetOctString_BN (oct, 32, bn);
    return bn;
}

int sm2_compute_key_with_option (const uint8_t * const peer_random_point,
                             const uint32_t peer_random_point_len_bytes,
                             const uint8_t * const peer_public_key,
                             const uint32_t peer_public_key_len_bytes,
                             const uint8_t * const self_public_key,
                             const uint32_t self_public_key_len_bytes,
                             const uint8_t * const self_random,
                             const uint32_t self_random_len_bytes,
                             const uint8_t * const self_random_point,
                             const uint32_t self_random_point_len_bytes,
                             const uint8_t * const peer_id,
                             const uint32_t peer_id_len_bytes,
                             const uint8_t * const self_id,
                             const uint32_t self_id_len_bytes,
                             const uint8_t * const self_private_key,
                             const uint32_t self_private_key_len_bytes,
                             uint8_t * const session_key,
                             const uint32_t session_key_len_bytes,
                             const uint32_t self_option_flag,
                             uint8_t * const self_option,
                             uint32_t * const self_option_len_bytes,
                             uint8_t * const option_verify,
                             uint32_t * const option_verify_len_bytes,
                             uint32_t const is_sponsor)
{
    int ret = session_key_len_bytes;
    //step 1: generate random rB
    //step 2: compute RB=[rB]G=(x2,y2)
    int size, ctxSize, pSize;
    int i, pointSize;
    IppStatus w;
    size = SM2_INTS;
    //RA = (x1,y1)
    IppsBigNumState *x1 = nBNSM2 ();
    ippsSetOctString_BN (peer_random_point + 1, 32, x1);
    IppsBigNumState *y1 = nBNSM2 ();
    ippsSetOctString_BN (peer_random_point + 33, 32, y1);
    //rB
    IppsBigNumState *rb = nBNSM2 ();
    ippsSetOctString_BN (self_random, self_random_len_bytes, rb);
    //RB=[rB]G = (x2,y2)
    IppsBigNumState *rbx = nBNSM2 ();
    ippsSetOctString_BN (self_random_point + 1, 32, rbx);
    IppsBigNumState *rby = nBNSM2 ();
    ippsSetOctString_BN (self_random_point + 33, 32, rby);
    //step 3: x2b = 2^w+(x2&2^2-1))
    IppsBigNumState *x2b = w2h (rbx);
    //step 4: compute tB = (dB+x2b*rB) mod n
    IppsBigNumState *db = nBNSM2 ();
    ippsSetOctString_BN (self_private_key, self_private_key_len_bytes, db);
    IppsBigNumState *tb = nBNSM2 ();
    //IppsBigNumState *tbm = nBNSM2 ();
    sm2_MontMul_BN (x2b, rb, sm2n, &tb);

#ifdef DEBUGKE
    Ipp32u ke_in_m[] =
        { 0xC32E79B7, 0x5AE74EE7, 0x0485628D, 0x29772063, 0xBF6FF7DD,
0xE8B92435, 0x4C044F18, 0x8542D69E };
    sm2_MontMul_BN (x2b, rb, ke_in_m, &tb);
#endif
    IppsBigNumState *n = nBNSM2 ();
    ippsSet_BN (1, 8, sm2n, n);
#ifdef DEBUGKE
    ippsSet_BN (1, 8, ke_in_m, n);
#endif

    ippsBigNumGetSize (SM2_INTS + 1, &ctxSize); // get the BigNum context Size
    IppsBigNumState *btb =
        (IppsBigNumState *) ippMalloc (sizeof (Ipp8u) * ctxSize);
    ippsBigNumInit (SM2_INTS + 1, btb); // BigNum context initialization
    w = ippsAdd_BN (tb, db, btb);

    ippsMod_BN (btb, n, tb);

    //step 5: check RA is on the curve?
    ippsECCPGetSize (SM2_BITS, &size);
    IppsECCPState *eccp = nECCP (SM2_BITS);
    //Using SM2 Curve
    w = ippsECCPSetStd (ippEC_TPM_SM2_P256, eccp);
#ifdef DEBUGKE
    //Using debug parameter
    IppsBigNumState *ke_p, *ke_a, *ke_b, *ke_gx, *ke_gy, *ke_n;
    Ipp32u ke_ip[] =
        { 0x08F1DFC3, 0x722EDB8B, 0x5C45517D, 0x45728391, 0xBF6FF7DE,
0xE8B92435, 0x4C044F18, 0x8542D69E };
    Ipp32u ke_ia[] =
        { 0x3937E498, 0xEC65228B, 0x6831D7E0, 0x2F3C848B, 0x73BBFEFF,
0x2417842E, 0xFA32C3FD, 0x787968B4 };
    Ipp32u ke_ib[] =
        { 0x27C5249A, 0x6E12D1DA, 0xB16BA06E, 0xF61D59A5, 0x484BFE48,
0x9CF84241, 0xB23B0C84, 0x63E4C6D3 };
    Ipp32u ke_igx[] =
        { 0x7FEDD43D, 0x4C4E6C14, 0xADD50BDC, 0x32220B3B, 0xC3CC315E,
    0x746434EB, 0x1B62EAB6, 0x421DEBD6 };
    Ipp32u ke_igy[] =
        { 0xE46E09A2, 0xA85841B9, 0xBFA36EA1, 0xE5D7FDFC, 0x153B70C4,
    0xD47349D2, 0xCBB42C07, 0x0680512B };
    Ipp32u ke_in[] =
        { 0xC32E79B7, 0x5AE74EE7, 0x0485628D, 0x29772063, 0xBF6FF7DD,
0xE8B92435, 0x4C044F18, 0x8542D69E };
    ke_p = nBNSM2 ();
    ke_a = nBNSM2 ();
    ke_b = nBNSM2 ();
    ke_gx = nBNSM2 ();
    ke_gy = nBNSM2 ();
    ke_n = nBNSM2 ();
    ippsSet_BN (1, 8, ke_ip, ke_p);
    ippsSet_BN (1, 8, ke_ia, ke_a);
    ippsSet_BN (1, 8, ke_ib, ke_b);
    ippsSet_BN (1, 8, ke_igx, ke_gx);
    ippsSet_BN (1, 8, ke_igy, ke_gy);
    ippsSet_BN (1, 8, ke_in, ke_n);

    w = ippsECCPSet (ke_p, ke_a, ke_b, ke_gx, ke_gy, ke_n, 1, eccp);
    printf ("ippsECCPSet status = %s\n", ippGetStatusString (w));

    if (ke_p)
        ippFree (ke_p);
    if (ke_a)
        ippFree (ke_a);
    if (ke_b)
        ippFree (ke_b);
    if (ke_gx)
        ippFree (ke_gx);
    if (ke_gy)
        ippFree (ke_gy);
    if (ke_n)
        ippFree (ke_n);
#endif
    ippsECCPPointGetSize (SM2_BITS, &pointSize);
    IppsECCPPointState *pra = nECCPPoint (SM2_BITS, pointSize);
    w = ippsECCPSetPoint (x1, y1, pra, eccp);
    IppECResult result;
    ippsECCPCheckPoint (pra, &result, eccp);
    if (result != ippECValid)
    {
        goto err;
    }
    //step 6: compute V=[h*tB](PA+[x1b]RA) = (xv,yv)
    IppsECCPPointState *pv = nECCPPoint (SM2_BITS, pointSize);
    IppsBigNumState *x1b = w2h (x1);
    w = ippsECCPMulPointScalar (pra, x1b, pv, eccp);    //[x1b]RA
    //initialize PA
    IppsECCPPointState *ppa = nECCPPoint (SM2_BITS, pointSize);
    IppsBigNumState *pax = nBNOctString (peer_public_key + 1);
    IppsBigNumState *pay = nBNOctString (peer_public_key + 33);
    w = ippsECCPSetPoint (pax, pay, ppa, eccp);

    w = ippsECCPAddPoint (ppa, pv, pv, eccp);   // PA+[x1b]RA
    w = ippsECCPMulPointScalar (pv, tb, pv, eccp);      //[tB](PA+[x1b]RA)
    //check V is infinite point?
    ippsECCPCheckPoint (pv, &result, eccp);
    if (result == ippECPointIsAtInfinite)
    {
        ret = 0;
        goto err;
    }
    w = ippsECCPGetPoint (pax, pay, pv, eccp);  // copy coordinate from point
    Ipp8u vxyzab[128];
    ippsGetOctString_BN (vxyzab, SM2_SIZE, pax);
    ippsGetOctString_BN (vxyzab + 32, SM2_SIZE, pay);

    //step 7: compute KB=KDF(xv||yv||ZA||ZB, klen)
    //generate ZA
    if (!is_sponsor)
    {
        generate_za (peer_id, 16, peer_public_key, 65, vxyzab + 64);
        generate_za (self_id, 16, self_public_key, 65, vxyzab + 96);
    }
    else
    {
        generate_za (self_id, 16, self_public_key, 65, vxyzab + 64);
        generate_za (peer_id, 16, peer_public_key, 65, vxyzab + 96);
    }

    kdf_sm3 (vxyzab, 128, session_key_len_bytes, session_key);

    //step 8: compute option 
    //  SB=Hash(0x02||yv||hash(xv||ZA||ZB||x1||y1||x2||y2))
    if (self_option_flag)
    {
        Ipp8u v1[1], v2[1];
        Ipp8u digest[32];
        ippsSM3GetSize (&size); //get SM3 size
        IppsSM3State *sm3_ctx =
            (IppsSM3State *) ippMalloc (sizeof (Ipp8u) * size);
        w = ippsSM3Init (sm3_ctx);
        w = ippsSM3Update (vxyzab, 32, sm3_ctx);        //put xv
        w = ippsSM3Update (vxyzab + 64, 64, sm3_ctx);   //put ZA||ZB
        if (!is_sponsor)
        {
            v1[0] = 3;
            v2[0] = 2;
            w = ippsSM3Update (peer_random_point + 1, 64, sm3_ctx);
            w = ippsSM3Update (self_random_point + 1, 64, sm3_ctx);
        }
        else
        {
            v1[0] = 2;
            v2[0] = 3;
            w = ippsSM3Update (self_random_point + 1, 64, sm3_ctx);
            w = ippsSM3Update (peer_random_point + 1, 64, sm3_ctx);
        }
        w = ippsSM3Final (digest, sm3_ctx);
        //generate self_option
        ippsSM3Init (sm3_ctx);
        ippsSM3Update (v1, 1, sm3_ctx);
        ippsSM3Update (vxyzab + 32, 32, sm3_ctx);       //put yv
        ippsSM3Update (digest, 32, sm3_ctx);    // put hash(xv||ZA||ZB||x1||y1||x2||y2)
        ippsSM3Final (self_option, sm3_ctx);
        //generate option_verify
        ippsSM3Init (sm3_ctx);
        ippsSM3Update (v2, 1, sm3_ctx);
        ippsSM3Update (vxyzab + 32, 32, sm3_ctx);       //put yv
        ippsSM3Update (digest, 32, sm3_ctx);    // put hash(xv||ZA||ZB||x1||y1||x2||y2)
        ippsSM3Final (option_verify, sm3_ctx);

        *self_option_len_bytes = 32;
        *option_verify_len_bytes = 32;
        if (sm3_ctx)
            ippFree (sm3_ctx);
        //step 9: send RB and SB (optional) to UserA
        //step 10: compute option
        //  S2 = Hash(0x03||yv||Hash(xv||ZA||ZB||x1||y1||x2||y2))
        //  S2 = SA?
    }
  err:
    if (eccp)
        ippFree (eccp);
    if (n)
        ippFree (n);
    if (x1)
        ippFree (x1);
    if (y1)
        ippFree (y1);
    if (rb)
        ippFree (rb);
    if (rby)
        ippFree (rby);
    if (rbx)
        ippFree (rbx);
    if (x2b)
        ippFree (x2b);
    if (tb)
        ippFree (tb);
    if (pv)
        ippFree (pv);
    if (ppa)
        ippFree (ppa);
    if (x1b)
        ippFree (x1b);
    if (pax)
        ippFree (pax);
    if (pay)
        ippFree (pay);
    if (btb)
        ippFree (btb);
    if (db)
        ippFree (db);
    if (pra)
        ippFree (pra);
    return ret;
}

// unsigned char pubkey[64+1];
int get_pubkey_from_ec_key(EC_KEY *ec_key, unsigned char *out, unsigned int len)
{
	if(ec_key == NULL || out == NULL || len <= 0)
		return -1;

	return EC_POINT_point2oct(EC_KEY_get0_group(ec_key), EC_KEY_get0_public_key(ec_key), POINT_CONVERSION_UNCOMPRESSED, out, len, NULL);
}

// unsigned char prikey[32+1];
int get_prikey_from_ec_key(EC_KEY *ec_key, unsigned char *out)
{
	if(ec_key == NULL || out == NULL)
		return -1;

	return BN_bn2bin(EC_KEY_get0_private_key(ec_key), out);
}
#endif
