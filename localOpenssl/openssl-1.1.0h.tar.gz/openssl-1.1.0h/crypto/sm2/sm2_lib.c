/* crypto/sm2/sm2_lib.c */
/* ====================================================================
 * Copyright (c) 2015 The GmSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the GmSSL Project.
 *    (http://gmssl.org/)"
 *
 * 4. The name "GmSSL Project" must not be used to endorse or promote
 *    products derived from this software without prior written
 *    permission. For written permission, please contact
 *    guanzhi1980@gmail.com.
 *
 * 5. Products derived from this software may not be called "GmSSL"
 *    nor may "GmSSL" appear in their names without prior written
 *    permission of the GmSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the GmSSL Project
 *    (http://gmssl.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE GmSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE GmSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 */


#include <stdio.h>
#include <assert.h>
#include <stdint.h>
#include <string.h>
#include "../../ssl/ssl_locl.h"
#include <openssl/ssl.h>
#include <openssl/bn.h>
#include <openssl/ec.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/sm2.h>
#include <openssl/sm3.h>
#include "sm2_ipp.h"

#define EC_MAX_NBYTES	((OPENSSL_ECC_MAX_FIELD_BITS + 7)/8)

static void *sm2_data_dup(void *data) {
	return OPENSSL_strdup((const char *)data);
}

static void sm2_data_free(void *data) {
	return OPENSSL_free(data);
}

int SM2_set_id(EC_KEY *ec_key, const char *id)
{
	char *pid;

	if (strlen(id) > SM2_MAX_ID_LENGTH) {
		return 0;
	}

	if ((pid = EC_KEY_get_key_method_data(ec_key, sm2_data_dup,
		sm2_data_free, sm2_data_free)) != NULL) {
		return 0;
	}

	if (!(pid = OPENSSL_strdup(id))) {
		return 0;
	}

	if (!EC_KEY_insert_key_method_data(ec_key, pid, sm2_data_dup,
		sm2_data_free, sm2_data_free)) {
		OPENSSL_free(pid);
		return 0;
	}

	return 1;
}

char *SM2_get_id(EC_KEY *ec_key)
{
	return (char *)EC_KEY_get_key_method_data(ec_key, sm2_data_dup,
		sm2_data_free, sm2_data_free);
}

/*
 * pkdata = a || b || G.x || G.y || P.x || P.y
 */
static int sm2_get_public_key_data(unsigned char *buf, EC_KEY *ec_key)
{
	int ret = -1;
	const EC_GROUP *ec_group = EC_KEY_get0_group(ec_key);
	const EC_POINT *point;
	int nbytes = (EC_GROUP_get_degree(ec_group) + 7) / 8;
	unsigned char oct[EC_MAX_NBYTES * 2 + 1];
	BN_CTX *bn_ctx = NULL;
	BIGNUM *p = NULL;
	BIGNUM *x = NULL;
	BIGNUM *y = NULL;
	size_t len;

	OPENSSL_assert(ec_key);
	OPENSSL_assert(nbytes == 256/8);
 
	if (!buf) {
		return (nbytes * 6);
	}
	memset(buf, 0, nbytes * 6);

	bn_ctx = BN_CTX_new();
	p = BN_new();
	x = BN_new();
	y = BN_new();
	if (!bn_ctx || !p || !x || !y) {
		goto err;
	}

	/* get curve coefficients a, b */
	if (!EC_GROUP_get_curve_GFp(ec_group, p, x, y, bn_ctx)) {
		goto err;
	}
	buf += nbytes;
	if (!BN_bn2bin(x, buf - BN_num_bytes(x))) {
		goto err;
	}
	buf += nbytes;
	if (!BN_bn2bin(y, buf - BN_num_bytes(y))) {
		goto err;
	}

	/* get curve generator coordinates */
	if (!(point = EC_GROUP_get0_generator(ec_group))) {
		goto err;
	}
	if (!(len = EC_POINT_point2oct(ec_group, point,
		POINT_CONVERSION_UNCOMPRESSED, oct, sizeof(oct), bn_ctx))) {
		goto err;
	}
	OPENSSL_assert(len == 32 * 2 + 1); 
	memcpy(buf, oct + 1, len - 1);
	buf += len - 1;

	/* get pub_key coorindates */
	if (!(point = EC_KEY_get0_public_key(ec_key))) {
		goto err;
	}
	if (!(len = EC_POINT_point2oct(ec_group, point,
		POINT_CONVERSION_UNCOMPRESSED, oct, sizeof(oct), bn_ctx))) {
		goto err;
	}
	OPENSSL_assert(len == 32 * 2 + 1); 
	memcpy(buf, oct + 1, len - 1);
	buf += len - 1;

	ret = (nbytes * 6);
err:
	if (bn_ctx) BN_CTX_free(bn_ctx);
	if (p) BN_free(p);
	if (x) BN_free(x);
	if (y) BN_free(y);

	return ret;
}

int SM2_compute_id_digest(unsigned char *dgst, unsigned int *dgstlen,
	const EVP_MD *md, const void *id, size_t idlen, EC_KEY *ec_key)
{
        int ret = 0;
        EVP_MD_CTX *md_ctx = NULL;
        unsigned char pkdata[EC_MAX_NBYTES * 6];
	uint16_t idbits = idlen * 8;
	int pkdatalen;
	
	if ((pkdatalen = sm2_get_public_key_data(pkdata, ec_key)) < 0) {
		goto err;
	}

	if (!(md_ctx = EVP_MD_CTX_create())) {
		goto err;
	}
	if (!EVP_DigestInit_ex(md_ctx, md, NULL)) {
		goto err;
	}
	if (!EVP_DigestUpdate(md_ctx, &idbits, sizeof(idbits))) {
		goto err;
	}
	if (!EVP_DigestUpdate(md_ctx, id, idlen)) {
		goto err;
	}
	if (!EVP_DigestUpdate(md_ctx, pkdata, pkdatalen)) {
		goto err;
	}
	if (!EVP_DigestFinal(md_ctx, dgst, dgstlen)) {
		goto err;
	}

	ret = 1;

err:
	if (md_ctx) EVP_MD_CTX_destroy(md_ctx);
        return ret;
}

static int get_z (const uint8_t * id, const uint32_t id_len_bytes, const uint8_t * public_key, 
		const uint32_t public_key_len_bytes,uint8_t * const z_output, 
		uint32_t * z_output_len_bytes)
{
	/*
	   ZA= H256(ENTLA||IDA||a||b||xG||yG||xA||yA) 
	   */

	int i, entla = id_len_bytes * 8;
	uint8_t msg[512] = {0};
	unsigned char sm2abgxgy[] = {
		0xFF, 0xFF, 0xFF, 0xFE, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
		0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00,
		0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFC, 0x28, 0xE9, 0xFA, 0x9E,
		0x9D, 0x9F, 0x5E, 0x34, 0x4D, 0x5A, 0x9E, 0x4B, 0xCF, 0x65, 0x09, 0xA7,
		0xF3, 0x97, 0x89, 0xF5, 0x15, 0xAB, 0x8F, 0x92, 0xDD, 0xBC, 0xBD, 0x41,
		0x4D, 0x94, 0x0E, 0x93, 0x32, 0xC4, 0xAE, 0x2C, 0x1F, 0x19, 0x81, 0x19,
		0x5F, 0x99, 0x04, 0x46, 0x6A, 0x39, 0xC9, 0x94, 0x8F, 0xE3, 0x0B, 0xBF,
		0xF2, 0x66, 0x0B, 0xE1, 0x71, 0x5A, 0x45, 0x89, 0x33, 0x4C, 0x74, 0xC7,
		0xBC, 0x37, 0x36, 0xA2, 0xF4, 0xF6, 0x77, 0x9C, 0x59, 0xBD, 0xCE, 0xE3,
		0x6B, 0x69, 0x21, 0x53, 0xD0, 0xA9, 0x87, 0x7C, 0xC6, 0x2A, 0x47, 0x40,
		0x02, 0xDF, 0x32, 0xE5, 0x21, 0x39, 0xF0, 0xA0
	};

	msg[1] = entla & 0xFF;
	msg[0] = (entla >> 8) & 0xFF;
	for (i = 0; i < id_len_bytes; i++)
		msg[2 + i] = id[i];
	entla = 2 + id_len_bytes;
	for (i = 0; i < 128; i++)
		msg[i + entla] = sm2abgxgy[i];
	entla += 128;
	for (i = 0; i < public_key_len_bytes - 1; i++)
		msg[i + entla + 65 - public_key_len_bytes] = public_key[i + 1];
	*z_output_len_bytes = 32;
	sm3(msg, id_len_bytes + 194, z_output);
	return 1;
}

static uint32_t kdf_sm3 (const uint8_t * z_input, const uint32_t z_len,
		const uint32_t klen, uint8_t const *outkey)
{
	uint32_t i;
	uint8_t zz[512] = {0};
	uint8_t digest[SM3_DIGEST_LENGTH];

	int rlen = klen;
	uint8_t *pp = (uint8_t *) outkey;

	for (i = 0; i < z_len; i++)
		zz[i] = z_input[i];

	i = 1;
	while (rlen > 0)
	{
		zz[z_len] = (i >> 24) & 0xff;
		zz[z_len + 1] = (i >> 16) & 0xFF;
		zz[z_len + 2] = (i >> 8) & 0xFF;
		zz[z_len + 3] = i & 0xff;
		sm3(zz, z_len + 4, digest);
		memcpy (pp, digest, (rlen >= SM3_DIGEST_LENGTH) ? SM3_DIGEST_LENGTH : rlen);
		rlen -= SM3_DIGEST_LENGTH;
		pp += SM3_DIGEST_LENGTH;
		i++;
	}
	rlen = 0;
	for (i = 0; i < z_len; i++)
		if ((outkey[i] & 0xFF) != 0)
		{
			rlen = 1;
			break;
		}
	if (rlen > 0)
	{
		return (klen / SM3_DIGEST_LENGTH + 1) * SM3_DIGEST_LENGTH;
	}
	else
	{
		return 0;
	}
}

static int SM2_compute_key_with_option (const EC_GROUP *sm2_group, const uint8_t * const peer_random_point, const uint32_t peer_random_point_len_bytes,
		const uint8_t * const peer_public_key, const uint32_t peer_public_key_len_bytes,
		const uint8_t * const self_public_key, const uint32_t self_public_key_len_bytes,
		const uint8_t * const self_random, const uint32_t self_random_len_bytes,
		const uint8_t * const self_random_point, const uint32_t self_random_point_len_bytes,
		const uint8_t * const peer_id, const uint32_t peer_id_len_bytes,
		const uint8_t * const self_id, const uint32_t self_id_len_bytes,
		const uint8_t * const self_private_key, const uint32_t self_private_key_len_bytes,
		uint8_t * const session_key, const uint32_t session_key_len_bytes,
		const uint32_t self_option_flag, uint8_t * const self_option,
		uint32_t * const self_option_len_bytes, uint8_t * const option_verify,
		uint32_t * const option_verify_len_bytes, uint32_t const is_server)
{
	BIGNUM *db = NULL, *w = NULL, *rb = NULL, *tb = NULL, *n = NULL;
	EC_POINT *pk = NULL, *crp = NULL, *pka = NULL;
	BN_CTX *ctx = NULL;

	uint8_t digest[32] = {0};
	uint8_t v1 = 0, v2 = 0;

	uint8_t temp_buff[512] = {0}; 
	BIGNUM *xv=NULL, *yv=NULL, *x1bar=NULL, *x2bar=NULL;
	int i, ret = 0;
	uint32_t temp = 0;

	if ((!(ctx = BN_CTX_new ())) || (!(n = BN_new ())) || (!(db = BN_new ()))
			|| (!(w = BN_new ()) || (!(x1bar = BN_new ())) || (!(x2bar = BN_new ()))) || (!(rb = BN_new ()))
			|| (!(tb = BN_new ())) || (!(xv = BN_new ())) || (!(yv = BN_new ())))
	{
		ret = -1;
		goto EndP;
	}

	BN_CTX_init(ctx);
	BN_CTX_start(ctx);

	if ((!BN_hex2bn (&w, "80000000000000000000000000000000")) || (!BN_bin2bn (self_private_key, self_private_key_len_bytes, db)))
	{
		ret = -1;
		goto EndP;
	}
	if ((!(pk = EC_POINT_new (sm2_group))) || (!(crp = EC_POINT_new (sm2_group)))
			|| (!(pka = EC_POINT_new (sm2_group))) || (!EC_GROUP_get_order (sm2_group, n, ctx)))
	{
		ret = -1;
		goto EndP;
	}
	//decodeing self random
	if ((!BN_bin2bn (self_random, self_random_len_bytes, rb))
			|| (!EC_POINT_oct2point (sm2_group, pk, self_random_point, self_random_point_len_bytes, ctx)))
	{
		ret = -1;
		goto EndP;
	}

	//B3 compute xbar
	EC_POINT_get_affine_coordinates_GFp (sm2_group, pk, x2bar, NULL, ctx);

	if (!BN_nnmod (x2bar, x2bar, w, ctx))
	{                       // x2bar = x2 & (2^w -1)
		ret = -1;
		goto EndP;
	}
	if (!BN_mod_add_quick (x2bar, x2bar, w, n))
	{                       //x2bar = 2^w+ (x2 & (2^w -1 ))
		ret = -1;
		goto EndP;
	}

	//B4 tb=(db+x2bar*rb) mod n
	if (!BN_mod_mul (tb, x2bar, rb, n, ctx))
	{
		ret = -1;
		goto EndP;
	}
	if (!BN_mod_add_quick (tb, tb, db, n))
	{
		ret = -1;
		goto EndP;
	}

	//decode peer's point
	if ((!EC_POINT_oct2point (sm2_group, crp, peer_random_point, peer_random_point_len_bytes, ctx))
			|| (!EC_POINT_oct2point (sm2_group, pka, peer_public_key, peer_public_key_len_bytes, ctx)))
	{

		ret = -1;
		goto EndP;
	}
	if (!EC_POINT_get_affine_coordinates_GFp (sm2_group, crp, x1bar, NULL, ctx))
	{
		ret = -1;
		goto EndP;
	}
	//B5 x1bar=2^w + (x1 & (2^w-1))
	BN_nnmod (x1bar, x1bar, w, ctx);
	BN_mod_add_quick (x1bar, x1bar, w, n);

	// //B6 V = [h 隆陇 tB](PA+[ 隆楼 x1]RA) = (xV ;yV )
	BN_mod_mul (x1bar, x1bar, tb, n, ctx);
	EC_POINT_mul (sm2_group, pka, NULL, pka, tb, ctx);
	EC_POINT_mul (sm2_group, crp, NULL, crp, x1bar, ctx);
	EC_POINT_add (sm2_group, pka, pka, crp, ctx);
	EC_POINT_get_affine_coordinates_GFp (sm2_group, pka, xv, yv, ctx);

	//buff struct: 02|04 || xV || yV || ZA || ZB || x1 || y1 || x2 || y2
	//B7  KB=KDF(xV||yV||ZA||ZB;klen)拢禄//xV拢卢yV拢卢ZA拢卢ZB碌脛鲁陇露脠脢脟露脿脡脵拢驴 脠莽鹿没脢脳脦禄脦陋0拢卢脢脟路帽潞枚脗脭拢驴脮芒脌茂脫脨脪脡脦脢拢驴卤戮掳忙卤戮虏脡脫脙虏鹿脝毛碌脛路陆脢陆麓娄脌铆
	//po_len = 
	EC_POINT_point2oct (sm2_group, pka, POINT_CONVERSION_UNCOMPRESSED, temp_buff, 65, ctx);
	if (is_server)
	{
		//get_z (peer_id, peer_id_len_bytes, peer_public_key, peer_public_key_len_bytes, temp_buff + 65, &temp);
		//get_z (self_id, self_id_len_bytes, self_public_key, self_public_key_len_bytes, temp_buff + 97, &temp);      //97=65+32
		get_z (peer_id, peer_id_len_bytes, peer_public_key, peer_public_key_len_bytes, temp_buff + 97, &temp);
		get_z (self_id, self_id_len_bytes, self_public_key, self_public_key_len_bytes, temp_buff + 65, &temp);      //97=65+32
		//copying x1||y1 and x2||y2
		for (i = 0; i < peer_random_point_len_bytes - 1; i++)
			temp_buff[194 + i - peer_random_point_len_bytes] = peer_random_point[i + 1];    //194=129+65 //129=97+32
		for (i = 0; i < self_random_point_len_bytes - 1; i++)
			temp_buff[258 + i - self_random_point_len_bytes] = self_random_point[i + 1];    //258=194+64
	}
	else
	{
		//get_z (self_id, self_id_len_bytes, self_public_key, self_public_key_len_bytes, temp_buff + 65, &temp);
		//get_z (peer_id, peer_id_len_bytes, peer_public_key, peer_public_key_len_bytes, temp_buff + 97, &temp);      //97=65+32
		get_z (self_id, self_id_len_bytes, self_public_key, self_public_key_len_bytes, temp_buff + 97, &temp);
		get_z (peer_id, peer_id_len_bytes, peer_public_key, peer_public_key_len_bytes, temp_buff + 65, &temp);      //97=65+32
		//copying x1||y1 and x2||y2
		for (i = 0; i < peer_random_point_len_bytes - 1; i++)
			temp_buff[258 + i - peer_random_point_len_bytes] = peer_random_point[i + 1];    //258=194+64
		for (i = 0; i < self_random_point_len_bytes - 1; i++)
			temp_buff[194 + i - self_random_point_len_bytes] = self_random_point[i + 1];    //194=129+65 //129=97+32
	}

	//generating session_key
	kdf_sm3 (temp_buff + 1, 128, session_key_len_bytes, session_key);

	if (!self_option_flag)
	{
		ret = session_key_len_bytes;
		goto EndP;
	}

	//switching xV and yV
	for (i = 0; i < 32; i++)
	{
		temp = temp_buff[i + 33];
		temp_buff[i + 33] = temp_buff[i + 1];
		temp_buff[i + 1] = temp;
	}

	//B8 SB= Hash(0x02||yV 隆脦Hash(xV||ZA||ZB||x1||y1||x2||y2))拢禄
	if (is_server)
	{
		v1 = 3;
		v2 = 2;
	}
	else
	{
		v1 = 2;
		v2 = 3;
	}

	sm3 (temp_buff + 33, 224, digest);
	for (i = 0; i < 32; i++)
		temp_buff[33 + i] = digest[i];
	temp_buff[0] = v1;

	sm3 (temp_buff, 65, self_option);
	*self_option_len_bytes = 32;
	temp_buff[0] = v2;
	sm3 (temp_buff, 65, option_verify);
	*option_verify_len_bytes = 32;

	ret = session_key_len_bytes;
EndP:
	BN_CTX_end(ctx);
	if(ctx) BN_CTX_free(ctx);
	if(n) BN_free(n);
	if(db) BN_free(db);
	if(x1bar) BN_free(x1bar);
	if(x2bar) BN_free(x2bar);
	if(xv) BN_free(xv);
	if(yv) BN_free(yv);
	if(tb) BN_free(tb);
	if(rb) BN_free(rb);
	if(w) BN_free(w);
	if(crp) EC_POINT_free(crp);
	if(pk) EC_POINT_free(pk);
	if(pka) EC_POINT_free(pka);

	return ret;
}

int SM2_compute_key(SSL *s, const EC_KEY *ecdh, const EC_POINT *point, unsigned char *out)
{
	int ret = 0;
	int len = 0;
	unsigned char tmp[32+1];
	unsigned char encPriKey[32+1];    //本端加密证书私钥
	unsigned char encPubKey[64+1];    //本端加密证书公钥	
	unsigned char priTmpKey[32+1];    //本端临时私钥
	unsigned char pubTmpKey[64+1];    //本端临时公钥
	unsigned char peerEncPubKey[64+1];    //对端加密证书公钥
	unsigned char peerPubTmpKey[64+1];    //对端临时公钥

	unsigned char *id = (unsigned char*)"1234567812345678";
	const EC_GROUP *group = EC_KEY_get0_group(ecdh);

	if(s->cert->pkeys[SSL_PKEY_ECC].x509 == NULL || s->cert->pkeys[SSL_PKEY_ECC].x509->cert_info->key->public_key->length != 65 || s->session->peer == NULL || s->session->peer->cert_info->key->public_key->length != 65)
	{
		//ECHO(stderr, "SM2_compute_key failed");
		return -1;
	}
	ret = BN_bn2bin(EC_KEY_get0_private_key(s->cert->pkeys[SSL_PKEY_ECC].privatekey->pkey.ec), encPriKey);
	if(ret != 32)
	{
		//ECHO(stderr, "BN_bn2bin failed: %d", ret);
		return -1;
	}
	memcpy(encPubKey, s->cert->pkeys[SSL_PKEY_ECC].x509->cert_info->key->public_key->data, 65);
#if 1
	len  = BN_bn2bin(EC_KEY_get0_private_key(ecdh), priTmpKey);
	if(len  <= 0)
	{
		//ECHO(stderr, "BN_bn2bin failed: %d", len );
		return -1;
	}
#else
	len = BN_bn2bin(EC_KEY_get0_private_key(ecdh), tmp);
	if(len <= 0)
	{
		//ECHO(stderr, "BN_bn2bin failed: %d", len);
		return -1;
	}
	memset(priTmpKey, 0, 32+1);
	memcpy(&priTmpKey[32-len], &tmp[0], len);
	len = 32;
#endif
	ret = EC_POINT_point2oct(group, EC_KEY_get0_public_key(ecdh), POINT_CONVERSION_UNCOMPRESSED, pubTmpKey, 65, NULL);
	if(ret != 65)
	{
		//ECHO(stderr, "EC_POINT_point2oct failed: %d", ret);
		return -1;
	}
	memcpy(peerEncPubKey, s->session->peer->cert_info->key->public_key->data, 65);
	ret = EC_POINT_point2oct(group, point, POINT_CONVERSION_UNCOMPRESSED, peerPubTmpKey, 65, NULL);
	if(ret != 65)
	{
		//ECHO(stderr, "EC_POINT_point2oct failed: %d", ret);
		return -1;
	}

#ifdef OPENSSL_WITH_INTEL
	return sm2_compute_key_with_option(peerPubTmpKey, 65, peerEncPubKey, 65, encPubKey, 65, priTmpKey, len, pubTmpKey, 65, \
		id, 16, id, 16, encPriKey, 32, out, 48, 0, NULL, NULL, NULL, NULL, s->server);
#else
	return SM2_compute_key_with_option(group, peerPubTmpKey, 65, peerEncPubKey, 65, encPubKey, 65, priTmpKey, len, pubTmpKey, 65, \
		id, 16, id, 16, encPriKey, 32, out, 48, 0, NULL, NULL, NULL, NULL, s->server);
#endif
}
