/* crypto/evp/e_sms4.c */
#include <stdio.h>
#include "cryptlib.h"

#ifndef OPENSSL_NO_SMS4
#include <openssl/evp.h>
#include <openssl/objects.h>
#include "evp_locl.h"
#include <openssl/sms4.h>

static int sms4_init_key(EVP_CIPHER_CTX *ctx, const unsigned char *key,
			 const unsigned char *iv,int enc);
static int sms4_128_cbc_cipher(EVP_CIPHER_CTX *ctx, unsigned char *out,
                            const unsigned char *in, size_t len);

typedef struct
{
	sms4_key_t ks;
} EVP_SMS4_KEY;


#if 0
IMPLEMENT_BLOCK_CIPHER(sms4, ks, sms4, EVP_SMS4_KEY, NID_sms4,
		       16, 16, 16, 128, 0, sms4_init_key, 0, 0, 0, 0)
#endif

static int sms4_init_key(EVP_CIPHER_CTX *ctx, const unsigned char *key,
			 const unsigned char *iv, int enc)
	{
	if(!enc) {
		if (EVP_CIPHER_CTX_mode(ctx) == EVP_CIPH_OFB_MODE) enc = 1;
		else if (EVP_CIPHER_CTX_mode(ctx) == EVP_CIPH_CFB_MODE) enc = 1;  //encrypt key == decrypt key
	}
	if (enc)
		sms4_set_encrypt_key(ctx->cipher_data, key);
	else        //ecb, cbc
		sms4_set_decrypt_key(ctx->cipher_data, key);
	return 1;
	}

static int sms4_128_cbc_cipher(EVP_CIPHER_CTX *ctx, unsigned char *out,
                            const unsigned char *in, size_t len)
{
    sms4_cbc_encrypt(in, out, len, ctx->cipher_data, ctx->iv, ctx->encrypt);

    return 1;
}

static const EVP_CIPHER sms4 =
{
    NID_sms4,
    16, 16, 16,
    EVP_CIPH_FLAG_DEFAULT_ASN1|EVP_CIPH_CBC_MODE,
    sms4_init_key,
    sms4_128_cbc_cipher,
    NULL,
    sizeof(EVP_SMS4_KEY),
    NULL,
    NULL,
    NULL,
    NULL
};

static const EVP_CIPHER sms4_cbc =
{
    NID_sms4_cbc,
    16, 16, 16,
    EVP_CIPH_FLAG_DEFAULT_ASN1|EVP_CIPH_CBC_MODE,
    sms4_init_key,
    sms4_128_cbc_cipher,
    NULL,
    sizeof(EVP_SMS4_KEY),
    NULL,
    NULL,
    NULL,
    NULL
};

const EVP_CIPHER *EVP_sms4(void)
{
    return &sms4;
}

const EVP_CIPHER *EVP_sms4_cbc(void)
{
    return &sms4_cbc;
}
#endif
